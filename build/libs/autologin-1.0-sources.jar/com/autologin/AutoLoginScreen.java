package com.autologin;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;

public class AutoLoginScreen extends class_437 {
	private final class_437 parent;
	private final AutoLoginConfig cfg = AutoLoginConfig.get();

	private class_342 passwordField;
	private class_4185 toggleButton;

	public AutoLoginScreen(class_437 parent) {
		super(class_2561.method_43471("autologin.screen.title"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		int cx = this.field_22789 / 2;
		int y = this.field_22790 / 2 - 45;

		toggleButton = method_37063(class_4185.method_46430(toggleText(), button -> {
			cfg.enabled = !cfg.enabled;
			button.method_25355(toggleText());
		}).method_46434(cx - 100, y, 200, 20).method_46431());

		passwordField = new class_342(this.field_22793, cx - 100, y + 45, 200, 20,
				class_2561.method_43471("autologin.screen.password"));
		passwordField.method_1880(128);
		passwordField.method_1852(cfg.password);
		method_37063(passwordField);

		method_37063(class_4185.method_46430(class_5244.field_24334, button -> this.method_25419())
				.method_46434(cx - 100, y + 85, 200, 20).method_46431());
	}

	private class_2561 toggleText() {
		return class_2561.method_43469("autologin.screen.enabled",
				cfg.enabled ? class_5244.field_24332 : class_5244.field_24333);
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		super.method_25394(context, mouseX, mouseY, delta);
		int cx = this.field_22789 / 2;
		int y = this.field_22790 / 2 - 45;
		context.method_27534(this.field_22793, this.field_22785, cx, y - 25, 0xFFFFFFFF);
		context.method_27535(this.field_22793,
				class_2561.method_43471("autologin.screen.password"), cx - 100, y + 33, 0xFFAAAAAA);
	}

	@Override
	public void method_25432() {
		cfg.password = passwordField.method_1882();
		AutoLoginConfig.save();
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(parent);
	}
}
