package com.autologin;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AutoLoginClient implements ClientModInitializer {
	public static final String MOD_ID = "autologin";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static final class_304.class_11900 CATEGORY =
			class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "main"));

	private static class_304 openSettingsKey;
	private static class_304 toggleKey;

	/** Тиков до отправки /login; -1 = ничего не ожидается. */
	private int pendingTicks = -1;

	@Override
	public void onInitializeClient() {
		AutoLoginConfig.load();

		// Открыть настройки (по умолчанию: Right Shift)
		openSettingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.autologin.open_settings",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				CATEGORY));

		// Быстро вкл/выкл мод (по умолчанию не назначен)
		toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.autologin.toggle",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_UNKNOWN,
				CATEGORY));

		// Игрок зашёл на сервер -> запланировать /login
		ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
			AutoLoginConfig cfg = AutoLoginConfig.get();
			if (!cfg.enabled || cfg.password.isEmpty() || client.method_1542()) {
				pendingTicks = -1;
				return;
			}
			pendingTicks = Math.max(1, cfg.delayTicks);
		});

		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> pendingTicks = -1);

		ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
	}

	private void onTick(class_310 client) {
		while (openSettingsKey.method_1436()) {
			client.method_1507(new AutoLoginScreen(client.field_1755));
		}

		while (toggleKey.method_1436()) {
			AutoLoginConfig cfg = AutoLoginConfig.get();
			cfg.enabled = !cfg.enabled;
			AutoLoginConfig.save();
			if (client.field_1724 != null) {
				client.field_1724.method_7353(class_2561.method_43471(
						cfg.enabled ? "autologin.message.enabled" : "autologin.message.disabled"), true);
			}
		}

		if (pendingTicks >= 0) {
			if (client.field_1724 == null || client.method_1562() == null) {
				return;
			}
			if (--pendingTicks == 0) {
				pendingTicks = -1;
				AutoLoginConfig cfg = AutoLoginConfig.get();
				if (cfg.enabled && !cfg.password.isEmpty()) {
					client.method_1562().method_45730("login " + cfg.password);
					client.field_1724.method_7353(class_2561.method_43471("autologin.message.sent"), true);
				}
			}
		}
	}
}
